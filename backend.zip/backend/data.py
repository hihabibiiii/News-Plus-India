news_data = [
    {
        "id": 1,
        "title": "Big breaking news from India impacting millions today",
        "category": "India",
        "image": "https://images.unsplash.com/photo-1581092334651-ddf26d9b66c6",
        "summary": "Major development reported from India today."
    },
    {
        "id": 2,
        "title": "Government announces major reform for youth employment",
        "category": "Politics",
        "image": "https://images.unsplash.com/photo-1529107386315-e1a2ed48a620",
        "summary": "New reform expected to benefit young professionals."
    },
    {
        "id": 3,
        "title": "India wins thrilling match in international tournament",
        "category": "Sports",
        "image": "https://images.unsplash.com/photo-1502877338535-766e1452684a",
        "summary": "A memorable victory for the Indian team."
    },

    {
        "id": 4,
        "title": "India wins thrilling match in international tournament",
        "category": "Sports",
        "image": "https://images.unsplash.com/photo-1502877338535-766e1452684a",
        "summary": "A memorable victory for the Indian team."
    },
    {
        "id": 5,
        "title": "India wins thrilling match in international tournament",
        "category": "Sports",
        "image": "https://images.unsplash.com/photo-1502877338535-766e1452684a",
        "summary": "A memorable victory for the Indian team."
    },
    {
        "id": 6,
        "title": "India wins thrilling match in international tournament",
        "category": "Sports",
        "image": "https://images.unsplash.com/photo-1502877338535-766e1452684a",
        "summary": "A memorable victory for the Indian team."
    },
    {
        "id": 11,
        "title": "India wins thrilling match in international tournament",
        "category": "Sports",
        "image": "https://images.unsplash.com/photo-1502877338535-766e1452684a",
        "summary": "A memorable victory for the Indian team."
    },
    {
        "id": 7,
        "title": "India wins thrilling match in international tournament",
        "category": "Sports",
        "image": "https://images.unsplash.com/photo-1502877338535-766e1452684a",
        "summary": "A memorable victory for the Indian team."
    },
    {
        "id": 8,
        "title": "India wins thrilling match in international tournament",
        "category": "Sports",
        "image": "https://images.unsplash.com/photo-1502877338535-766e1452684a",
        "summary": "A memorable victory for the Indian team."
    },
    {
        "id": 9,
        "title": "India wins thrilling match in international tournament",
        "category": "Sports",
        "image": "https://images.unsplash.com/photo-1502877338535-766e1452684a",
        "summary": "A memorable victory for the Indian team."
    },
    {
        "id": 10,
        "title": "India wins thrilling match inwefwe international tournament",
        "category": "Sports",
        "image": "https://images.unsplash.com/photo-1502877338535-766e1452684a",
        "summary": "A memorable victory for the Indian team.A memorable victory for the Indian team.A memorable victory for the Indian team.A memorable victory for the Indian team.A memorable victory for the Indian team.A memorable victory for the Indian team.A memorable victory for the Indian team.A memorable victory for the Indian team.A memorable victory for the Indian team.A memorable victory for the Indian team.A memorable victory for the Indian team.A memorable victory for the Indian team.A memorable victory for the Indian team.A memorable victory for the Indian team.A memorable victory for the Indian team."
    },
]
